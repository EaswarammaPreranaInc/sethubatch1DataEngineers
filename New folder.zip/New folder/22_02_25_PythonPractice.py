#Find outputs
import keyword #How  to  import   kw  list
print(keyword.kwlist)#How  to  print  kwlist
print(len(keyword.kwlist))#How  to  print  number  of  keywords
print(type(keyword.kwlist))#How  to  print  type  of kwlist
print(keyword . kwlist)
#  Find  outputs  (Home  work)
import keyword#How  to  import   keyword  module
print(keyword.kwlist) # How  to  print  kwlist
print(len(keyword.kwlist)) # How  to  print  number  of  keywords
print(type(keyword.kwlist)) # How  to  print  type  of kwlist
print(keyword.kwlist)