units = int(input('Enter  units :   '))
match  int(units/100):
	case 0:
		cost =units*3
	case 1:
	    cost =100*3 + (units-100)*3.5
	case 2 | 3:
		cost =100*3 + 100*3.5 + (units-200)*4
	case  4 | 5 | 6:
		cost =100*3 + 100*3.5 + 200*4 + (units-400)*4.5
	case _:
		cost=100*3 + 100*3.5 + 200*4 + 300*4.5 + (units-700)*5
print('Bill  amount  :  ',cost)






'''Enter  fahrenheit  temperature : 100
celsius   equivalent :  37.78
Enter  1  to  convert  celsius  to  farenheit  and  2  to  convert  fahrenheit  to  celsius :  1
Enter  celsius  temperature :  30
Fahrenheit  Equivalent  :  86.0
Enter  1  to  convert  celsius  to  farenheit  and  2  to  convert  fahrenheit  to  celsius :  3
Invalid input	
'''
		
