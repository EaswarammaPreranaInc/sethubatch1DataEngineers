#  Find  outputs  (Home  work)
def  change(b):
	b . append(25) # Appends 25 to list
	b[2] = 17 # modifies at index 2 to 17
	del  b[1] # delete the element at index 1
# End  of  the  function
a = [10 , 20 , 15 , 18]
print(a) # [10 , 20 , 15 , 18]
change(a) # calls the function and modifies a
print(a) # [10, 17, 18, 25]
# Find  outputs  (Home  work)
def  change(b):
	b  = [50 , 60 , 70 , 80]
	print(b) # [50 , 60 , 70 , 80]
# End  of  the  function
a = [10 , 20 , 30 , 40]
print(a) # [10 , 20 , 30 , 40]
change(a) # calls the function and modifies a
print(a) # [10 , 20 , 30 , 40]
#  Find  outputs  (Home  work)
def   f1(x):
	x = 20
	print(x) # 20
# End  of   the   function
x = 10
print(x) # 10
f1(x) # calls the function
print(x)
#  Find  outputs  (Home  work)
def  f1(b):
	b[2] = 25 # Error becoz tuple element can't be modified by indexing
#end  of  the  function
a = (10 , 20 , 15 , 18)
print(a) # (10 , 20 , 15 , 18)
#f1(a) # calls the function
print(a) # (10 , 20 , 15 , 18)