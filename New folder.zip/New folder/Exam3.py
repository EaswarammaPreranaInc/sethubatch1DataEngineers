'''n = input('Enter a no:')
for i in range(len(n)):
    match (n[i]):
        case '0' : 
            print('Zero',end=' ')
        case '1' : 
            print('One',end=' ') 
        case '2' :
            print('Two',end=' ')  
        case '3' :
            print('Three',end=' ')
        case '4' : 
            print('Four',end=' ')
        case '5' : 
            print('Five',end=' ') 
        case '6' :
            print('Six',end=' ')  
        case '7' :
            print('Seven',end=' ')    
        case '8' :
            print('Eight',end=' ')  
        case '9' :
            print('Nine',end=' ')    '''

n = int(input('Enter a no:'))
for i in range(1,n+1):
    print(' '*(2*n-i) + '* ' * (2*i-2 if i>1 else 1))
for k in range(n-1,0,-1):
    print(' '*(2*n-k) + '* '*(2*k-2 if k>1 else 1))    