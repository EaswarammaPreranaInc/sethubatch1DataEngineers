a = input('enter a string:')
b = a.split()
c = []
for i in b:
    c.append([i.upper(),len(i)])
print(c)    